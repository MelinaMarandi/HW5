//MelinaMarandi
//40223074
#include <stdio.h>
#include <string.h>

int main()
{
	//Declare Variables
	
    
char string[10][30]; //2D array for storing strings
	int i, n,j,k;
	//Get the maximum number of strings
	printf("Enter number of strings to input\n");
	scanf("%d", &n);

	//Read the string from user
	
	for(i=0; i< n ; i++) {
        printf("Enter Strings one by one: \n");
		scanf("%s",string[i]);
	}  
for(j=0;j<n;j++)
{
    if(string[j]==string[j+1])
    {
        printf("%s",string[j]-string[j+1]);
    }
    else{
        printf("%s",string[j]);
    }
}
for(k=1;k<n;k++)
{
    if(string[k]==string[k+1])
    {
        printf("%s\t",string[k]-string[k+1]);
    }
    else{
        printf("%s\t",string[k]);
    }
}
int z=strlen(string);
for(int p=2;p<z;p++)
{
if(string[p]==string[p+1])
    {
        printf("%s",string[p]-string[p+1]);
    }
    else{
        printf("%s",string[p]);
    }
}

}  